<div class="alt-full-card">
  <div class="card-title">
    <div class="card-title-text">
      <i class="fas fa-palette"></i><span class="parent-link">Customize</span>
    </div>
    <div class="card-title-button">
    </div>
  </div>

  <div class="alt-card-body">
    <div class="information-grant-header">
      <p>Presets</p>
    </div>

    <div class="preset">

    </div>
    <div class="preset">

    </div>
    <div class="preset">

    </div>
    <div class="preset">

    </div>


  </div>
</div>
